package com.demo;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/aaa")
public class confirmpayment extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Retrieve Tender ID from the form
        String tenderId = request.getParameter("tenderid");

        Connection con = null;
        PreparedStatement ps = null;

        try {
            // Load JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish Database Connection
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/agrolabour", "root", "");

            // Update payment status to "Confirmed"
            String updateQuery = "UPDATE tender_details_status SET payment_status = 'Confirmed' WHERE tenderid = ?";
            ps = con.prepareStatement(updateQuery);
            ps.setString(1, tenderId);

            int result = ps.executeUpdate();

            if (result > 0) {
                out.println("<html><head><title>Payment Confirmation</title></head><body>");
                out.println("<h2 style='color: green; text-align: center;'>Payment Confirmed Successfully!</h2>");
                out.println("<p style='text-align: center;'>Tender ID: <b>" + tenderId + "</b></p>");
                out.println("<div style='text-align: center;'><a href='index.jsp'>Back to Home</a></div>");
                out.println("</body></html>");
            } else {
                out.println("<h2 style='color: red;'>Payment Confirmation Failed. Please try again.</h2>");
            }
        } catch (Exception e) {
            out.println("<h2 style='color: red;'>Error: " + e.getMessage() + "</h2>");
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
