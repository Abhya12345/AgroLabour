package com.demo;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.io.PrintWriter;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/delete")
public class deletelabour extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out=resp.getWriter();
		String id=req.getParameter("d");
	
	Integer cid=Integer.parseInt(id);
	
	try {
        Class.forName("com.mysql.jdbc.Driver");
        String url = "jdbc:mysql://localhost:3306/agrolabour";
        String username = "root";
        String password = "";
        Connection con = DriverManager.getConnection(url, username, password);
        String q="delete from labour where id=?";
        PreparedStatement pst=con.prepareStatement(q);
        pst.setString(1,id);


int i=pst.executeUpdate();
if(i>0) {
RequestDispatcher rd=req.getRequestDispatcher("/managelabour.jsp")      ;
rd.forward(req, resp);
}
else {
out.println("data not inserted.............");
}

    }catch(Exception e){
        out.println(e);
    }


}
	
	
	}


