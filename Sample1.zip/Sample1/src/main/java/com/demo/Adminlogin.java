package com.demo;


import java.io.IOException;
import java.io.PrintWriter;
import java.net.ConnectException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/loginform")
public class Adminlogin extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String name = request.getParameter("username");
		String pass = request.getParameter("password");

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/agrolabour", "root", "");
			PreparedStatement ps = con.prepareStatement("select * from admin where loginname=? and password=?");
			ps.setString(1, name);
			ps.setString(2, pass);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				RequestDispatcher rd = request.getRequestDispatcher("/Adminprofile.jsp");
				rd.include(request, response);
			} else {
				request.setAttribute("errorMessage", "Invalid username or password. Please try again.");
				RequestDispatcher rd = request.getRequestDispatcher("/Adminlogin.jsp");
				rd.forward(request, response);
			}
		} catch (Exception e) {
			request.setAttribute("errorMessage", "Something went wrong. Please try again.");
			RequestDispatcher rd = request.getRequestDispatcher("/Adminlogin.jsp");
			rd.forward(request, response);
		}
	}
}
