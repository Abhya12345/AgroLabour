package com.demo;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/accept")
public class accepttender extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String tenderid = request.getParameter("tenderid");

        if (tenderid != null) {
            try {
                // Database Connection
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/agrolabour", "root", "");
                PreparedStatement ps = con.prepareStatement("UPDATE tender_details_status SET status = 'Accepted' WHERE tenderid = ?");
                ps.setString(1, tenderid);
                int rowsAffected = ps.executeUpdate();

                if (rowsAffected > 0) {
                    // Display success message with animation
                    out.println("<!DOCTYPE html>");
                    out.println("<html lang='en'>");
                    out.println("<head>");
                    out.println("<meta charset='UTF-8'>");
                    out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
                    out.println("<title>Tender Accepted</title>");
                    out.println("<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>");
                    out.println("<style>");
                    out.println("body { display: flex; justify-content: center; align-items: center; height: 100vh; background: linear-gradient(120deg, #84fab0, #8fd3f4); }");
                    out.println(".card { text-align: center; padding: 30px; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2); border-radius: 20px; }");
                    out.println(".success-icon { font-size: 50px; color: green; animation: bounce 1s infinite; }");
                    out.println("@keyframes bounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }");
                    out.println("</style>");
                    out.println("</head>");
                    out.println("<body>");

                    out.println("<div class='card bg-white'>");
                    out.println("<h1 class='text-success'>✅ Tender Accepted!</h1>");
                    out.println("<p class='text-muted'>Tender ID: <strong>" + tenderid + "</strong></p>");
                    out.println("<p>Your tender has been successfully accepted.</p>");
                    out.println("<a href='contracterprofile.jsp' class='btn btn-primary'>Go Home</a>");
                    out.println("</div>");

                    out.println("</body>");
                    out.println("</html>");
                } else {
                    out.println("<script>alert('Error: Tender not found or already processed!'); window.location='tender_list.jsp';</script>");
                }

                ps.close();
                con.close();
            } catch (Exception e) {
                out.println("<script>alert('Error: " + e.getMessage() + "'); window.location='tender_list.jsp';</script>");
            }
        } else {
            out.println("<script>alert('Tender ID is missing!'); window.location='tender_list.jsp';</script>");
        }
    }
}
