package com.demo;


import java.io.IOException;
import java.io.PrintWriter;
//import java.net.ConnectException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/contracterlogin")
public class contracterlogin extends HttpServlet

{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out =response.getWriter();
		String name=request.getParameter("username");
		String pass=request.getParameter("password");
		try{
			

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/agrolabour","root","");
		PreparedStatement ps=con.prepareStatement("select * from contracter where username=? and password=?");
		ps.setString(1, name);
		ps.setString(2, pass);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
		{
			//HttpSession Session=request.getSession();
			//Session.setAttribute("session_name", rs.getString("name"));
			RequestDispatcher rd=request.getRequestDispatcher("/contracterprofile.jsp");
			rd.include(request, response);
			
		}
		else{
			
			RequestDispatcher rd=request.getRequestDispatcher("/contracterlogin.jsp");
			rd.include(request, response);
			
		}
		}
		catch(Exception e)
		{
			out.println("somethong went wrong plz try again..");
			//RequestDispatcher rd=request.getRequestDispatcher("/Adminlogin.jsp");
				//	rd.include(request, response);
		}




		
	}

}
