package com.demo;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/contracter")
public class contracterreg extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html");

        String f_name = request.getParameter("name");
        String u_name = request.getParameter("u_name");
        String ph_no = request.getParameter("ph_no");
        String pass = request.getParameter("pass");
        String address = request.getParameter("address");
        String gender = "male"; // or get it from a parameter if needed

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/agrolabour", "root", "");
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO contracter(name, username, phone, password, address, gender) VALUES (?,?,?,?,?,?)");

            ps.setString(1, f_name);
            ps.setString(2, u_name);
            ps.setString(3, ph_no);
            ps.setString(4, pass);
            ps.setString(5, address);
            ps.setString(6, gender);

            int count = ps.executeUpdate();

            if (count > 0) {
                // Set success message
                request.setAttribute("message", "Registered successfully.");
                RequestDispatcher rd = request.getRequestDispatcher("/contracterlogin.jsp");
                rd.forward(request, response);
            } else {
                request.setAttribute("errorMessage", "Registration failed. Please try again.");
                RequestDispatcher rd = request.getRequestDispatcher("/contracterlogin.jsp");
                rd.forward(request, response);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Something went wrong. Please try again.");
            RequestDispatcher rd = request.getRequestDispatcher("/contracterlogin.jsp");
            rd.forward(request, response);
        }
    }
}
