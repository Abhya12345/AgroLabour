package com.demo;



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/update")
public class updatelabour extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		 resp.setContentType("text/html");
		PrintWriter out=resp.getWriter();
		String id=req.getParameter("id");
		String name=req.getParameter("name");
		String username=req.getParameter("username");
		String phone=req.getParameter("phone");
		String address=req.getParameter("address");
		//String storage=req.getParameter("s");
		//String os=req.getParameter("os");
	
		

		        try {
		            Class.forName("com.mysql.jdbc.Driver");
		            String url = "jdbc:mysql://localhost:3306/agrolabour";
		            String username1 = "root";
		            //String password = "";
		            Connection con = DriverManager.getConnection(url, username1,"");
		            String q="update labour set name=?, username=?,phone=?, address=? where id=?";
		            PreparedStatement pst=con.prepareStatement(q);
                 
                    pst.setString(1,name);
                    pst.setString(2,username);
        pst.setString(3,phone);
        pst.setString(4,address);
        pst.setString(5,id);
       // pst.setString(5,storage);
        //pst.setString(6,os);

        
        int i=pst.executeUpdate();
        if(i>0) 
        {
        	RequestDispatcher rd=req.getRequestDispatcher("/viewlabour.jsp")      ;
        	
        	rd.forward(req, resp);
        	out.print("<h1 style='color :green'>labour details updated successfully.</h1>");
        }
        else {
        	
        	
        }

		        }catch(Exception e){
		            out.println(e);
		        }
		
		
}

}