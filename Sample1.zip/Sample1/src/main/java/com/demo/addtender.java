package com.demo;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/addtender")
public class addtender extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        // Retrieve form parameters and handle potential null values
        String idStr = request.getParameter("id");
        String farmerIdStr = request.getParameter("f_id");
        String f_name = request.getParameter("name");
        String address = request.getParameter("address");
        String ph_no = request.getParameter("phone");
        String f_size = request.getParameter("f_size");
        String n = request.getParameter("n");
        String p = request.getParameter("p");

        // Validate and parse integer fields
        int id = (idStr != null && !idStr.isEmpty()) ? Integer.parseInt(idStr) : 0;
        int farmerId = (farmerIdStr != null && !farmerIdStr.isEmpty()) ? Integer.parseInt(farmerIdStr) : 0;

        // Database connection variables
        Connection con = null;
        PreparedStatement ps = null;
        PreparedStatement ps2 = null;

        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish Connection
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/agrolabour", "root", "");

            // Insert into `tender_details`
            String sql1 = "INSERT INTO tender_details (farmerid, farmer_name, field_address, phone, field_size, No_of_labours, tender_price) VALUES (?, ?, ?, ?, ?, ?, ?)";
            ps = con.prepareStatement(sql1);
            ps.setInt(1, farmerId);
            ps.setString(2, f_name);
            ps.setString(3, address);
            ps.setString(4, ph_no);
            ps.setString(5, f_size);
            ps.setString(6, n);
            ps.setString(7, p);
            ps.executeUpdate();

            // Insert into `tender_details_status`
            String sql2 = "INSERT INTO tender_details_status (farmerid, farmer_name, field_address, phone, field_size, No_of_labours, tender_price, status,payment_status) VALUES (?,? ,?, ?, ?, ?, ?, ?, ?)";
            ps2 = con.prepareStatement(sql2);
            ps2.setInt(1, farmerId);
            ps2.setString(2, f_name);
            ps2.setString(3, address);
            ps2.setString(4, ph_no);
            ps2.setString(5, f_size);
            ps2.setString(6, n);
            ps2.setString(7, p);
            ps2.setString(8, "Pending");
            ps2.setString(9, "Pending");
           // ps2.setString(10, "Pending");
                     // Default status

            ps2.executeUpdate();

            out.println("<h3 style='color:green;'>Tender added successfully!</h3>");

        } catch (NumberFormatException e) {
            out.println("<h3 style='color:red;'>Error: Invalid number format in input fields.</h3>");
        } catch (Exception e) {
            out.println("<h3 style='color:red;'>Error: " + e.getMessage() + "</h3>");
        } finally {
            try { if (ps != null) ps.close(); } catch (SQLException e) { /* ignore */ }
            try { if (ps2 != null) ps2.close(); } catch (SQLException e) { /* ignore */ }
            try { if (con != null) con.close(); } catch (SQLException e) { /* ignore */ }
        }
    }
}
