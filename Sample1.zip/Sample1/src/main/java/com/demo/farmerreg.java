package com.demo;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/farmerreg")
public class farmerreg extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");

        String f_name = request.getParameter("name");
        String u_name = request.getParameter("username");
        String ph_no = request.getParameter("phone");
        String address = request.getParameter("address");
        String farm1 = request.getParameter("farm");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/agrolabour", "root", "root");
            PreparedStatement ps = con.prepareStatement("INSERT INTO farmer (name,username,phone,address,field_size) VALUES (?,?,?,?,?)");

            ps.setString(1, f_name);
            ps.setString(2, u_name);
            ps.setString(3, ph_no);
            ps.setString(4, address);
            ps.setString(5, farm1);

            int count = ps.executeUpdate();

            if (count > 0) {
                // Pass success message as a request attribute
                request.setAttribute("message", "Login successfully.");
                RequestDispatcher rd = request.getRequestDispatcher("/farmerlogin.jsp");
                rd.forward(request, response);
            } else {
                request.setAttribute("message", "Registration failed. Please try again.");
                RequestDispatcher rd = request.getRequestDispatcher("/farmerlogin.jsp");
                rd.forward(request, response);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}
