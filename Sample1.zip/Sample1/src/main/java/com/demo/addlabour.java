package com.demo;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/addlabour")
public class addlabour extends HttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	 
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		//String id1=request.getParameter("id");
		//int id=Integer.parseInt(id1);
		    String f_name=request.getParameter("name");
			String u_name=request.getParameter("username");
 		String ph_no=request.getParameter("phone");
 		
 		String address=request.getParameter("address");
 		
 		
 		try
 		{
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/agrolabour","root","");
        PreparedStatement ps=con.prepareStatement("insert into labour(name,username,phone,address) values(?,?,?,?)");
       // ps.setInt(1, id);
        ps.setString(1, f_name);
        ps.setString(2,u_name);
        ps.setString(3, ph_no);
       // ps.setString(5, pass);
        ps.setString(4, address);
       // ps.setString(7, gender);

        Integer count=ps.executeUpdate();

        if (count >0)
        {
        	
        	RequestDispatcher rd=request.getRequestDispatcher("/addlabour.jsp");
        	rd.include(request, response);
        	out.print("<h1 style='color :green'>inserrted successfully.</h1>");
        }
        else
        	{
        		out.print(" not inserted");
        		RequestDispatcher rd=request.getRequestDispatcher("/weblog");
        		rd.include(request, response);

        	}
 		}
 		catch(ClassNotFoundException | SQLException e)
 		{
 			e.printStackTrace();
 		}

		    
		
	
	
	}

}
